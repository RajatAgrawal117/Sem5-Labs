x = input("Enter any number")
print(x)