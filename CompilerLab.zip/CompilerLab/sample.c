int num = 10;
char name[] = "jimit";
int age = 19;
int main()
{
    char name='j';
    printf("Hello World\n");
    // printf("Name: %s\n", name);
    if(age > 18)
    {
        printf("You are eligible to vote\n");
    }
    else
    {
        printf("You are not eligible to vote\n");
    }
    return 0;
}
