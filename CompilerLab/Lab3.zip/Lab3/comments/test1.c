#include <stdio.h>

// this is a single line comment

// this is second single line comment


int main(){
	printf("this is a sample file 1\n");
	return 0;}

// this is third single line comment

/*
this 
is a
multiline
comment
*/

/*
this is
second multiline
comment
*/
