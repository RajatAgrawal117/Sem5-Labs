#include <stdio.h>






int main(){
	printf("this is a sample file 1\n");
	return 0;}






